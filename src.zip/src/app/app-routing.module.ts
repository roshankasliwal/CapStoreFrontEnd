import { PaymentComponent } from './payment/payment.component';
import { ShowBillingAddressesComponent } from './show-billing-addresses/show-billing-addresses.component';
import { BillingAddressComponent } from './billing-address/billing-address.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {path:'addBillingAddress',component:BillingAddressComponent},
  {path:'showBillingAddress',component:ShowBillingAddressesComponent},
  {path:'payment',component:PaymentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
