import { FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  cashOnDeliver:boolean;
  debit:boolean;
  credit:boolean=true;
  netBanking:boolean;

  constructor(private formBuilder:FormBuilder) { }

  ngOnInit(): void {
  }

creditForm=this.formBuilder.group({
    name:["",[Validators.required,Validators.pattern('[a-zA-Z ]*')]],
    cardNumber:["",[Validators.required,Validators.pattern('\\d{16}')]],
    month:["",[Validators.required,Validators.pattern("^(1[012]|0?[1-9])$")]],
    year:["",[Validators.required,Validators.pattern('2[0-9]\\d{2}')]],
    cvv:["",[Validators.required,Validators.pattern('\\d{3}')]]
});

debitForm=this.formBuilder.group({
  name:["",[Validators.required,Validators.pattern('[a-zA-Z ]*')]],
  cardNumber:["",[Validators.required,Validators.pattern('\\d{16}')]],
  month:["",[Validators.required,Validators.pattern("^(1[012]|0?[1-9])$")]],
  year:["",[Validators.required,Validators.pattern('2[0-9]\\d{2}')]],
  cvv:["",[Validators.required,Validators.pattern('\\d{3}')]]
});

  setCashOnDelivery(){
    this.cashOnDeliver=true;
    this.debit=false;
    this.credit=false;
    this.netBanking=false;
  }
  setDebit(){
    this.cashOnDeliver=false;
    this.debit=true;
    this.credit=false;
    this.netBanking=false;
  }
  setCredit(){
    this.cashOnDeliver=false;
    this.debit=false;
    this.credit=true;
    this.netBanking=false;
  }
  setNetBanking(){
    this.cashOnDeliver=false;
    this.debit=false;
    this.credit=false;
    this.netBanking=true;
  }

}
